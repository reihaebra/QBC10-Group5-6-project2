export const items = [
    { image: '../../../public/images/Apple iPhone 14 Pro.jpg', name: "Apple iPhone 14 Pro", quantity: 1, price: 1000 },
    { image: "../../../public/images/Apple MacBook Air M2.jpg", name: "Apple MacBook Air M2", quantity: 2, price: 1000 },
    { image: "../../../public/images/Apple iPad Pro 12.9-inch.jpeg", name: "Apple iPad Pro 12.9-inch", quantity: 1, price: 1000 },
  ];
